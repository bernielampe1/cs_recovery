function display(A)
%DISPLAY  Display operator.
%
%   DISPLAY(A) displays an operator.

% ASP Toolbox
% Copyright 2008, Michael P. Friedlander and Michael A. Saunders
% http://www.cs.ubc.ca/labs/scl/asp
%
% $Id: display.m 455 2009-05-11 22:05:16Z mpf $

disp(A,inputname(1));
