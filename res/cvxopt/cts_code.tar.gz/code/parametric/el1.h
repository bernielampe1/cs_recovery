double * solveEl1sparse(
   int sparsity,
   int counter_arg,
	int counter2_arg,
   double *rng_gauss,
   int *rng_idx
   );
